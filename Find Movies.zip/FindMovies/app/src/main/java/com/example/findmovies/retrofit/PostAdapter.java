package com.example.findmovies.retrofit;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.findmovies.R;

import java.util.List;

public class PostAdapter extends RecyclerView.Adapter <PostAdapter.ViewHolder> {

    public List<Searching> movieList;

    public PostAdapter(List<Searching> movieList) {
        this.movieList = movieList;
    }

    @NonNull
    @Override
    public PostAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.tvName.setText(movieList.get(position).getTitle());

    }

    @Override
    public int getItemCount() {
        return movieList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvName;
        ImageView ivLogo;
        public ViewHolder(@NonNull View itemView){
            super(itemView);


            tvName = itemView.findViewById(R.id.title);


        }
    }
}
