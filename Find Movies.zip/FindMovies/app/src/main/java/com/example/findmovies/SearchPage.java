package com.example.findmovies;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.findmovies.retrofit.PostAdapter;
import com.example.findmovies.retrofit.ResultsFilm;
import com.example.findmovies.retrofit.Retro;
import com.example.findmovies.retrofit.Searching;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchPage extends AppCompatActivity {
 RecyclerView recyclerView;
 LinearLayoutManager linearLayoutManager;
 PostAdapter adapter;
 List<Searching> searchingList = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_page);
recyclerView = findViewById(R.id.rcview);
linearLayoutManager = new LinearLayoutManager(this);
recyclerView.setLayoutManager(linearLayoutManager);
adapter = new PostAdapter(searchingList);
recyclerView.setAdapter(adapter);
fetchPosts();

    }

    private void fetchPosts() {
        Retro.getClient().getMovie("Spider").enqueue(new Callback<ResultsFilm>() {
            @Override
            public void onResponse(Call<ResultsFilm> call, Response<ResultsFilm> response) {
                if (response.isSuccessful() && response.body() != null){
                    Log.d("ziya1",response.body().getResults().get(0).getTitle());{
                        searchingList.addAll(response.body().getResults());
                        adapter.notifyDataSetChanged();


                    }
                }
            }

            @Override
            public void onFailure(Call<ResultsFilm> call, Throwable t) {
                Toast.makeText(SearchPage.this, "Hata", Toast.LENGTH_SHORT).show();
            }
        });
    }


}

