package com.example.findmovies;

public class Base_Url {
    public static final String BASE_URL =
            "https://api.themoviedb.org/3/";
}
