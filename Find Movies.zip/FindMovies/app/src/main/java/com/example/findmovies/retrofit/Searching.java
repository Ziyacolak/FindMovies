package com.example.findmovies.retrofit;

import android.graphics.drawable.Icon;

public class Searching {

   private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Searching(String title) {
        this.title = title;
    }
}
